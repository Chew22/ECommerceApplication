package com.example.ecommerceapplication.models;

import java.io.Serializable;

public class NewProductsModel implements Serializable {

    String publisher;
    String productId;
    String description;
    String name;
    String rating;
    double price;
    String img_url;

    public NewProductsModel() {
    }

    public NewProductsModel(String publisher, String productId, String description, String name, String rating, double price, String img_url) {
        this.publisher = publisher;
        this.productId = productId;
        this.description = description;
        this.name = name;
        this.rating = rating;
        this.price = price;
        this.img_url = img_url;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }
}
