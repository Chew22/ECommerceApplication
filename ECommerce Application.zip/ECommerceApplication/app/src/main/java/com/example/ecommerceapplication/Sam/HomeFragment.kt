package com.example.ecommerceapplication.Sam

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.fragment.app.Fragment
// import androidx.navigation.fragment.findNavController
import com.example.ecommerceapplication.R
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeFragment : Fragment(R.layout.sam_fragment_home) {

//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        super.onViewCreated(view, savedInstanceState)
//
//        // Find the BottomNavigationView by ID
//        val bottomNavigationView = activity?.findViewById<BottomNavigationView>(R.id.bottomNavigation)
//
//        // Set click listener for the profile icon in the bottom menu
//        bottomNavigationView?.setOnNavigationItemSelectedListener { item ->
//            when (item.itemId) {
//                R.id.userAccountFragment -> {
//                    // Navigate to the UserAccountFragment when the profile icon is clicked
//                    findNavController().navigate(R.id.action_homeFragment_to_userAccountFragment)
//                    true
//                }
//                else -> false
//            }
//        }
//
//        // Find the ImageView by ID
//        val productImage = view.findViewById<ImageView>(R.id.productImage)
//
//        // Set click listener for the productImage ImageView
//        productImage.setOnClickListener {
//            onProductImageClick(it)
//        }
//
//        // Find the ImageView by ID
//        val faqImage = view.findViewById<ImageView>(R.id.roundin8)
//
//        // Set click listener for the faqImage ImageView
//        faqImage.setOnClickListener {
//            onFaqImageClick(it)
//        }
//
//        // Find the Button by ID (Replace with the actual ID of your button)
//        val orderButton = view.findViewById<ImageView>(R.id.roundin3)
//
//        // Set click listener for the orderButton
//        orderButton.setOnClickListener {
//            onOrderClick(it)
//        }
    }

//    // New method for handling Order button click
//    fun onOrderClick(view: View) {
//        // Handle the click event here
//        // For example, you can navigate to the Order Fragment
//        findNavController().navigate(R.id.action_homeFragment_to_orderFragment)
//    }
//
//    fun onFaqImageClick(view: View) {
//        // Handle the click event here
//        // For example, you can navigate to the FAQ fragment
//        findNavController().navigate(R.id.action_homeFragment_to_faqFragment)
//    }
//
//    // Move the function definition outside onViewCreated
//    fun onProductImageClick(view: View) {
//        // Handle the click event here
//        // For example, you can navigate to another fragment
//        findNavController().navigate(R.id.action_homeFragment_to_productdisplayFragment)
//    }
// mm}
